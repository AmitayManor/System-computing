#ifndef PERMISSION_H
#define PERMISSION_H

typedef enum {
    eNOPERMISSION,
    ePLANET,
    eSOLARSYSTEM,
    eGALAXY,
    eNUMOFPERMISSION
} Permission;

#endif // PERMISSION_H